public enum CengNodeType
{
    Internal,
    Leaf,
}
